<?php
    $a = $_GET["test"];

    if($a == 1){
        echo "Все верно";
    }
?>
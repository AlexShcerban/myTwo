function generateDescrip(){
    let bodyBlock = document.getElementById("contentName");

    
}